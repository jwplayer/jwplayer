export default {
    tagged: {
        file: 'sample',
        type: 'flv'
    }
};
