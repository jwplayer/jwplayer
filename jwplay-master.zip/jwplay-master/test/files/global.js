/* eslint-disable no-unused-vars */

var globalScriptExport = {
    description: 'This file is used to test the script loader'
};

var globalScriptLoaded = true;
