export const MetaBufferLength = 1;
export const MaxBufferLength = 25;
