export const version: string = __BUILD_VERSION__;
