import PromiseModule from 'promise-polyfill/src/index';

(function() {}(window.Promise || (window.Promise = PromiseModule)));
